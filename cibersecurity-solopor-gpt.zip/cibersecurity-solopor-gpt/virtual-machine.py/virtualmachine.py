# Importar las bibliotecas necesarias
import pandas as pd
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.naive_bayes import MultinomialNB
from sklearn.pipeline import make_pipeline
from sklearn.model_selection import train_test_split
from sklearn import metrics

# Función para leer datos desde un archivo CSV
def read_data(file_path):
    data = pd.read_csv(file_path)
    return data

# Función para preprocesar datos
def preprocess_data(data):
    texts = data['Actividad']
    labels = data['Estado']
    return texts, labels

# Ruta del archivo CSV
file_path = 'datos.csv'

# Leer y preprocesar los datos
data = read_data(file_path)
texts, labels = preprocess_data(data)

# Dividir los datos en conjuntos de entrenamiento y prueba
X_train, X_test, y_train, y_test = train_test_split(texts, labels, test_size=0.3, random_state=42)

# Crear un pipeline de procesamiento y entrenamiento
model = make_pipeline(CountVectorizer(), MultinomialNB())

# Entrenar el modelo
model.fit(X_train, y_train)

# Hacer predicciones
predicted = model.predict(X_test)

# Evaluar el modelo
accuracy = metrics.accuracy_score(y_test, predicted)
print(f'Precisión del modelo: {accuracy}')
