# Crear un entorno virtual (el nombre del entorno es 'venv', pero puedes cambiarlo)
python -m venv venv

# Activar el entorno virtual (en Windows)
venv\Scripts\activate

# Activar el entorno virtual (en macOS/Linux)
source venv/bin/activate
